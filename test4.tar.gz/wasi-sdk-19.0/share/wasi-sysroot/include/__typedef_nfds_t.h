#ifndef __wasilibc___typedef_nfds_t_h
#define __wasilibc___typedef_nfds_t_h

typedef unsigned long nfds_t;

#endif
