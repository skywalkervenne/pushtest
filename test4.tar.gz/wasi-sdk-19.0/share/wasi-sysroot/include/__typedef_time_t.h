#ifndef __wasilibc___typedef_time_t_h
#define __wasilibc___typedef_time_t_h

/* Define this as a 64-bit signed integer to avoid the 2038 bug. */
typedef long long time_t;

#endif
